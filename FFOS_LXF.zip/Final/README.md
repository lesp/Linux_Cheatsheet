This is a basic app for Firefox OS, made for Linux Format magazine.
This code is released under a Creative Commons CC-BY-SA licence, and you are
free to modify and re-use the code under the terms of this licence.

Have fun and good luck

@biglesp
